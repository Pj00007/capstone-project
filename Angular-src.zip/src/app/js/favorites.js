[{ 
    "id" : 1,
    "name" : "user1",
    "books" : 
    [{
        "bookname":"book1",
        "author":"author1",
        "publish_date":"2000"
     },
     {
        "bookname":"book2",
        "author":"author2",
        "publish_date":"2000"
     }]
},
{ 
    "id" : 2,
    "name" : "user2",
    "books" : 
    [{
        "bookname":"book3",
        "author":"author3",
        "publish_date":"2000"
     },
     {
        "bookname":"book4",
        "author":"author4",
        "publish_date":"2000"
     }]
},
{ 
    "id" : 3,
    "name" : "user3",
    "books" : 
    [{
        "bookname":"book1",
        "author":"author1",
        "publish_date":"2000"
     },
     {
        "bookname":"book2",
        "author":"author2",
        "publish_date":"2000"
     }]
},
{ 
    "id" : 4,
    "name" : "user4",
    "books" : 
    [{
        "bookname":"book1",
        "author":"author1",
        "publish_date":"2000"
     },
     {
        "bookname":"book2",
        "author":"author2",
        "publish_date":"2000"
     }]
}]