package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Book;
import com.example.demo.model.details;
import com.example.demo.repo.BookRepo;
import com.example.demo.repo.bookdetailsRepo;
import com.example.demo.service.BookService;






@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class BookController {

	@Autowired
	private BookService service;
	@Autowired
	private BookRepo repo;
	@Autowired
	private bookdetailsRepo bookrepo;
	
	@PostMapping("/home")
	public Book createUser(@RequestBody Book user) throws Exception {
		String tempEmail = user.getEmail();
		String tempPassword = user.getPassword();
		String tempName=user.getName();
				if(tempEmail!=null && tempPassword!=null && tempName!=null)
				{
					Book userObj1=service.fetchUserByEmail(tempEmail);
					Book userObj2=service.fetchUserByPassword(tempPassword);
					Book userObj3=service.fetchUserByName(tempName);
					if(userObj1!=null || userObj2!=null || userObj3!=null)
					{
						throw new Exception("Email id, username and password already exist!!");
					}
				}
		Book userobj=null;
		userobj=service.saveUser(user);
		return userobj;	
    }
	
	@PostMapping("/home/login")
	public Book Userlogin(@RequestBody Book user) throws Exception {
		String tempName=user.getName();
		String tempPassword= user.getPassword();
		Book userObj=null;
		if(tempName!=null && tempPassword!=null)
		{
			userObj=service.fetchUserByNameAndPassword(tempName, tempPassword);	
		}
		if(userObj != null)
		{
		}
		else
		{
			throw new Exception("Bad credentials");
		}
		return userObj;
		
	}
	
	@GetMapping("/home/{id}")
	public ResponseEntity<Optional<Book>> getEmployeeById(@PathVariable Integer id) throws Exception{
		Optional<Book> employee = repo.findById(id);
				if(employee==null)
				{
					throw new Exception("Employee not exist");
				}
				
		return ResponseEntity.ok(employee);
	}
	
	
	@PutMapping("/home/forgetPassword")
	public Book forgetPassword(@RequestBody Book user) throws Exception {
		String tempEmail=user.getEmail();
		String tempPassword= user.getPassword();
		Book userObj=null;
		
		if(tempEmail!=null && tempPassword!=null)
		{
			userObj=service.fetchUserByEmail(tempEmail);
		}
		
		if(userObj != null)
		{
			
			userObj.setPassword(tempPassword);
			//userObj.setEmail(user.getEmail());
			//userObj.setName(user.getName());
			//userObj.setPhone(user.getPhone());
			Book userobj=null;
			userobj=service.saveUser(userObj);
		}
		else
		{
			throw new Exception("Bad credentials for forget password");
		}
		return userObj;
	}
	
	@PostMapping("/home/bookdetails")
	public details createBook(@RequestBody details bookDetails) throws Exception {
		
		details ob=service.saveBook(bookDetails);
		return ob;
	}
	
	@GetMapping("/home/favorites")
	public List<details> getfavoritenames(@RequestParam String username){
		return service.findByNames(username);
	}
	
	// delete employee rest api
		@DeleteMapping("home/delete/{id}")
		public ResponseEntity<Map<String, Boolean>> deletebook(@PathVariable Long id){
			details details = bookrepo.findById(id);
					
			
			bookrepo.delete(details);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}
}
