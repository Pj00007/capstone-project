package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Book;
import com.example.demo.model.details;

public interface bookdetailsRepo extends JpaRepository<details, Integer>{

	 public List<details> findAllByusername(String username);

	public details findById(Long id);


	
	
}
