package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Book;
import com.example.demo.model.details;
import com.example.demo.repo.BookRepo;
import com.example.demo.repo.bookdetailsRepo;


@Service
public class BookService {

	@Autowired
	private BookRepo repo;
	
	@Autowired
	private bookdetailsRepo bookrepo;
	
	
	public Book saveUser(Book user)
	{
		return repo.save(user);
	}
	public details saveBook(details bookDetails)
	{
		return bookrepo.save(bookDetails);
	}
	public List<details> findByNames(String username)
	{
		return bookrepo.findAllByusername(username);
		
	}
	
	public Book fetchUserByNameAndPassword(String name,String password)
	{
		return repo.findByNameAndPassword(name, password);
	}

	public Book fetchUserByPhone(String phone) {
		
		return repo.findByPhone(phone);
	}

	public Book fetchUserByEmail(String tempEmail) {
		return repo.findByEmail(tempEmail);
	}
	
	public Book fetchUserByPassword(String tempPassword) {
		return repo.findByPassword(tempPassword);
	}
   public Book fetchUserByName(String name) {
		
		return repo.findByName(name);
	}
	
}
