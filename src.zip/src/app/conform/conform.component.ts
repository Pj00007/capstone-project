import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conform',
  templateUrl: './conform.component.html',
  styleUrls: ['./conform.component.css']
})
export class ConformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
