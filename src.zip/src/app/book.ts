export class Book {
    id!:number;
    username!:string;
    title!:string;
    authorName!:string;
    publish_date!:string;
    publish_year!:string;
    publisher!:string;
    language!:string;
}
