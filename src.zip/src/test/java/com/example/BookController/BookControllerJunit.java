package com.example.BookController;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.example.demo.model.Book;
import com.example.demo.model.details;
import com.example.demo.repo.bookdetailsRepo;
import com.example.demo.service.BookService;

//@InjectMocks
public class BookControllerJunit {
    private details detail;
    private Book book;
    
    List<details>list;
    @BeforeEach
    public void setUp() {
    	detail=new details();
    	book=new Book();
    	detail.setTitle("Batman.");
    	detail.setUsername("sarada");
    	detail.setPublish_date("2021");
    	detail.setPublish_year("2021");
    	detail.setLanguage("ita");
    	detail.setId(41);
    	detail.setPublisher("Independently Published");
    	book.setName("sarada");
        list=new ArrayList<>();
        list.add(detail);
       
    }
    
    @AfterEach
    public void tearDown() {
    	book=null;
    	detail=null;
    }
	

	
	
	@Test
    public void testfetchbyName() throws Exception {
    	BookService service = mock(BookService.class);
        when(service.fetchUserByName("sarada")).thenReturn(book);
        Book dummy = service.fetchUserByName("sarada");
        assertNotNull(dummy);
    }
	@Test
    public void testfetchbynameandpassword() throws Exception {
    	BookService service = mock(BookService.class);
        when(service.fetchUserByNameAndPassword("satya", "11")).thenReturn(book);
        Book dummy = service.fetchUserByNameAndPassword("satya", "11");
        assertNotNull(dummy);
    }
	@Test
    public void testgetfavoritenames() throws Exception {
		BookService service = mock(BookService.class);
		
		
		List<details> list=service.findByNames("sarada");
        
		assertNotNull(list);
    }
}
